import logging
import azure.functions as func
from opencensus.trace import config_integration
from opencensus.trace.tracer import Tracer
from opencensus.trace.samplers import AlwaysOnSampler

# Configure OpenCensus with logging integration
config_integration.trace_integrations(['logging'])
tracer = Tracer(sampler=AlwaysOnSampler())
app = func.FunctionApp()

@app.route(route="opencensus", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def opencensus(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

    with tracer.span(name='my_custom_span'):
        name = req.params.get('name')
        if not name:
            try:
                req_body = req.get_json()
            except ValueError:
                pass
            else:
                name = req_body.get('name')

        if name:
            return func.HttpResponse(f"Hello, {name}. This HTTP triggered function executed successfully.")
        else:
            return func.HttpResponse(
                "This HTTP triggered function executed successfully. Pass a name in the query string or in the request body for a personalized response.",
                status_code=200
            )
