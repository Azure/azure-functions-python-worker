# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.
"""Minimal v2 (decorator) programming model HTTP trigger.

Used by the cold-start profiling tests to exercise the proxy_worker +
azure_functions_runtime (v2) path on Python 3.13+. Keep this file as
small as practical — every import here adds to the cold-start profile.
"""
import logging

import azure.functions as func

app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)


@app.route(route="HttpTrigger")
def http_trigger(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

    name = req.params.get('name')
    if not name:
        try:
            req_body = req.get_json()
        except ValueError:
            pass
        else:
            name = req_body.get('name')

    if name:
        return func.HttpResponse(
            f"Hello, {name}. This HTTP triggered function executed "
            "successfully."
        )
    return func.HttpResponse(
        "This HTTP triggered function executed successfully. Pass a "
        "name in the query string or in the request body for a "
        "personalized response.",
        status_code=200,
    )
