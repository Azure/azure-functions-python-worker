# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.
#
# Based on the Azure-Samples blob_samples_blobclient sample:
# https://github.com/Azure-Samples/azure-functions-blob-sdk-bindings-python
#
# This fixture verifies that the azurefunctions blob SDK (deferred) bindings
# extension package is importable and usable under Flex Consumption. It is a
# plain anonymous HTTP app (no storage-backed binding), so it does not depend
# on a storage account being reachable from inside the mesh container.

import azure.functions as func
import azurefunctions.extensions.bindings.blob as blob

app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)


@app.route(route="sdk_bindings_check")
def sdk_bindings_check(req: func.HttpRequest) -> func.HttpResponse:
    # Referencing the SDK binding type confirms the extension imported and the
    # app indexed successfully under Flex Consumption.
    return func.HttpResponse(f"BlobClient: {blob.BlobClient.__name__}")
