# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.
#
# Based on the Azure-Samples blob_samples_blobclient sample:
# https://github.com/Azure-Samples/azure-functions-blob-sdk-bindings-python
#
# This fixture verifies that the azurefunctions blob SDK (deferred) bindings
# extension loads and indexes correctly under Flex Consumption.

import logging

import azure.functions as func
import azurefunctions.extensions.bindings.blob as blob

app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)


@app.route(route="sdk_bindings_check")
def sdk_bindings_check(req: func.HttpRequest) -> func.HttpResponse:
    # Referencing the SDK binding type confirms the extension imported and
    # the app indexed successfully under Flex Consumption.
    return func.HttpResponse(f"BlobClient: {blob.BlobClient.__name__}")


@app.route(route="file")
@app.blob_input(
    arg_name="client", path="PATH/TO/BLOB", connection="StorageConnection"
)
def blob_input(req: func.HttpRequest, client: blob.BlobClient):
    logging.info(
        f"Python blob input function processed blob \n"
        f"Properties: {client.get_blob_properties()}\n"
        f"Blob content head: {client.download_blob().read(size=1)}"
    )
    return "ok"
