import azure.functions as func

from azure.functions.extension.fastapi import Request, StreamingResponse

app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)

@app.route(route="http_v2_fastapi_streaming")
async def http_v2_fastapi_streaming(req: Request) -> StreamingResponse:
    # Define a list to accumulate the streaming data
    data_chunks = []

    async def process_stream():
        async for chunk in req.stream():
            # Append each chunk of streaming data to the list
            data_chunks.append(chunk)

    await process_stream()

    async def stream_data():
        for data_chunks in data_chunks:
            # Yield each chunk of streaming data
            yield data_chunks

    # Return the complete data as the response
    return StreamingResponse(stream_data())

    