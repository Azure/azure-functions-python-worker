import azure.functions as func
import sys
 
app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)

@app.route(route="httptrigger")
def main(req: func.HttpRequest) -> func.HttpResponse:
    sys.exit(137)
    return func.HttpResponse("")