import logging
import sys
import os
import json

# Check if import works overlapped protobuf and grpc
import azure.functions as func
import google.protobuf as proto
import grpc

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

    # Get all the environment variables as a dictionary
    env_vars = dict(os.environ)

    return func.HttpResponse(
        body=json.dumps({
            "azure.functions": func.__version__,
            "google.protobuf": proto.__version__,
            "grpc": grpc.__version__,
            "env_vars": env_vars
        }),
        status_code=200,
        mimetype="application/json"
    )
