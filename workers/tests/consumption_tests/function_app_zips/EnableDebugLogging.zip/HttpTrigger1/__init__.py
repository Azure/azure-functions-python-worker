import logging

import azure.functions as func


def main(req: func.HttpRequest) -> func.HttpResponse:
    # logging.info('iNITIAL Logger level is: ' + logging.getLogger().level)
    # logging.setLevel(logging.DEBUG)
    logging.info(f'Logger level is: {logging.getLogger().level}')
    logging.critical('logging critical', exc_info=True)
    logging.info('logging info', exc_info=True)
    logging.warning('logging warning', exc_info=True)
    logging.debug('logging debug', exc_info=True)
    logging.error('logging error', exc_info=True)
    
    return func.HttpResponse("OK-debug", status_code=200)
