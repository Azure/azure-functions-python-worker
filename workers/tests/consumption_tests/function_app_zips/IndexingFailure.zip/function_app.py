# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.
import logging
import sys

import azure.functions as func

app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)


@app.route(route="http_trigger")
def http_trigger(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

    name = req.params.get('name')
    if not name:
        try:
            req_body = req.get_json()
        except ValueError:
            pass
        else:
            name = req_body.get('name')

    if name:
        return func.HttpResponse(f"Hello, {name}. This HTTP triggered function executed successfully.")
    else:
        return func.HttpResponse(
             "This HTTP triggered function executed successfully. Pass a name in the query string or in the request body for a personalized response.",
             status_code=200
        )

@app.bad_route(route="hello")
def hello(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request. Python version: %s. azure-functions version: %s', sys.version, func.__version__)
    return f'Python version: {sys.version}. azure-functions version: {func.__version__}. {nonexistent_variable}'


# @app.retry(
#     strategy="exponential_backoff",
#     max_retry_count="3",
#     # manually setting the retry intervals will also not work
#     # minimum_interval="00:00:02",
#     # maximum_interval="00:01:00",
# )
# @app.event_hub_message_trigger(
#     arg_name="azeventhub",
#     event_hub_name="veventhub",
#     connection="AzureWebJobsEventHubConnectionString",
#     consumer_group="$Default",
# ) 
# def eventhub_trigger(azeventhub: func.EventHubEvent):
#     body = azeventhub.get_body().decode("utf-8")
#     logging.info(f'Python EventHub trigger processed an event: {body}')